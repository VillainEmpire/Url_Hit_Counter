package com.geekster.Url_Hit_counter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrlHitCounterApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrlHitCounterApplication.class, args);
	}

}
